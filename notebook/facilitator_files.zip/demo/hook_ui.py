"""Dark/purple theme + live-mic recorder UI for `demo/hook_demo.ipynb`.

Presentation only. Nothing here touches labelling, minutes generation, or
any file under `prototype/` -- it reads the same Markdown string
`prototype/demo.py`'s `run_demo()` / `run_demo_staged()` already returns,
and renders it as cards. The mic-recording wire path (ffmpeg conversion,
webm -> wav, stopping the mic tracks) is the same as the original
`record_skit()`; only the on-page UI changed, from a text "press Enter"
prompt to on-canvas Record/Stop buttons with a live waveform, frequency
bars, and a silence meter.

Not imported by `notebook/audio_workshop.ipynb` (the participants' notebook)
-- this is facilitator-only, bundled into `facilitator_files.zip` by
`notebook/make_bundle.py`.
"""
import os
import re
import subprocess
from base64 import b64decode

from IPython.display import HTML, Javascript, display

# ---------------------------------------------------------------------------
# Theme (from Asy's deck)
# ---------------------------------------------------------------------------

BG0 = "#0D0D12"
BG1 = "#15151C"
CARD = "#2E2E3C"
PURPLE = "#8B5CF6"
PURPLE2 = "#A855F7"
PINK = "#EC4899"
GREEN = "#22C55E"
TEXT = "#F4F4F8"
MUTED = "#9CA3AF"

FONT_CSS = (
    '<link rel="preconnect" href="https://fonts.googleapis.com">'
    '<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" '
    'rel="stylesheet">'
)

_THEME_CSS = """
<style>
.wsx * { font-family: 'Poppins', 'Segoe UI', system-ui, sans-serif; box-sizing: border-box; }
.wsx { color: __TEXT__; }
.wsx-banner {
  background: linear-gradient(135deg, __BG1__ 0%, __BG0__ 100%);
  border-radius: 18px; padding: 28px 32px; margin: 6px 0 18px 0;
  border: 1px solid __PURPLE__44;
  box-shadow: 0 0 40px __PURPLE__33;
}
.wsx-banner h1 {
  margin: 0; font-size: 34px; font-weight: 700; letter-spacing: 0.3px;
  background: linear-gradient(90deg, __PURPLE2__, __PINK__);
  -webkit-background-clip: text; background-clip: text; color: transparent;
}
.wsx-banner p { margin: 6px 0 0 0; color: __MUTED__; font-size: 15px; }
.wsx-card {
  background: __CARD__; border-radius: 16px; padding: 20px 24px; margin: 10px 0;
  border: 1px solid #ffffff14; box-shadow: 0 0 26px __PURPLE__22;
}
.wsx-card h3 { margin: 0 0 10px 0; font-size: 18px; font-weight: 600; color: __TEXT__; }
.wsx-record-btn, .wsx-stop-btn {
  border: none; border-radius: 999px; font-weight: 600; font-size: 15px;
  padding: 14px 28px; cursor: pointer; color: __TEXT__; margin-right: 10px;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.wsx-record-btn {
  background: radial-gradient(circle at 30% 30%, __PURPLE2__, __PURPLE__);
  box-shadow: 0 0 22px __PURPLE__88;
}
.wsx-record-btn:hover:enabled { transform: scale(1.04); }
.wsx-record-btn:disabled { opacity: 0.35; cursor: default; box-shadow: none; }
.wsx-stop-btn {
  background: __CARD__; border: 1px solid __PINK__;
}
.wsx-stop-btn:disabled { opacity: 0.35; cursor: default; }
.wsx-timer { font-size: 22px; font-weight: 600; color: __PURPLE2__; margin-left: 6px; letter-spacing: 1px; }
.wsx-status { font-size: 13px; color: __MUTED__; margin-top: 6px; min-height: 18px; }
.wsx-canvas-wrap { margin-top: 14px; border-radius: 12px; overflow: hidden; background: __BG0__; }
.wsx-silence-row { margin-top: 10px; }
.wsx-silence-label { font-size: 12px; color: __MUTED__; margin-bottom: 4px; }
.wsx-silence-track { background: #ffffff14; border-radius: 999px; height: 8px; overflow: hidden; }
.wsx-silence-fill { background: linear-gradient(90deg, __PURPLE__, __PINK__); height: 100%; width: 0%; transition: width 0.08s linear; }
.wsx-silence-flash { color: __PINK__; font-weight: 600; }
.wsx-progress-strip { display: flex; gap: 8px; margin: 14px 0; flex-wrap: wrap; }
.wsx-stage {
  padding: 7px 14px; border-radius: 999px; font-size: 13px; font-weight: 500;
  background: #ffffff0d; color: __MUTED__; border: 1px solid #ffffff14;
}
.wsx-stage.active {
  background: __PURPLE__22; color: __TEXT__; border-color: __PURPLE__;
  box-shadow: 0 0 14px __PURPLE__55;
}
.wsx-stage.done { background: __GREEN__22; color: __GREEN__; border-color: __GREEN__55; }
.wsx-minutes-grid { display: flex; gap: 18px; flex-wrap: wrap; margin-top: 10px; }
.wsx-minutes-col { flex: 1; min-width: 260px; }
.wsx-minutes-col h4 { margin: 0 0 10px 0; font-size: 15px; color: __PURPLE2__; text-transform: uppercase; letter-spacing: 0.08em; }
.wsx-item {
  background: __BG1__; border-left: 3px solid __PURPLE__; border-radius: 10px;
  padding: 12px 14px; margin-bottom: 10px; box-shadow: 0 0 14px __PURPLE__18;
}
.wsx-item.action { border-left-color: __PINK__; }
.wsx-item-text { font-size: 14.5px; color: __TEXT__; }
.wsx-pill {
  display: inline-block; font-size: 11.5px; padding: 3px 10px; border-radius: 999px;
  margin: 6px 4px 0 0; background: #ffffff10; color: __MUTED__;
}
.wsx-pill.owner { color: __PURPLE2__; background: __PURPLE__1a; }
.wsx-pill.due { color: __PINK__; background: __PINK__1a; }
.wsx-empty { color: __MUTED__; font-size: 13.5px; font-style: italic; }
.wsx-attendees { color: __MUTED__; font-size: 13px; margin-bottom: 4px; }
</style>
"""


def _css() -> str:
    return (_THEME_CSS
            .replace("__BG0__", BG0).replace("__BG1__", BG1).replace("__CARD__", CARD)
            .replace("__PURPLE2__", PURPLE2).replace("__PURPLE__", PURPLE)
            .replace("__PINK__", PINK).replace("__GREEN__", GREEN)
            .replace("__TEXT__", TEXT).replace("__MUTED__", MUTED))


def inject_theme() -> None:
    """Call once (cell 2) -- loads Poppins and the shared card/button CSS."""
    display(HTML(FONT_CSS + _css()))


def title_banner(title: str, subtitle: str = "") -> None:
    sub = f"<p>{subtitle}</p>" if subtitle else ""
    display(HTML(f'<div class="wsx wsx-banner"><h1>{title}</h1>{sub}</div>'))


# ---------------------------------------------------------------------------
# Live-mic recorder with on-canvas visualizer
# ---------------------------------------------------------------------------

# Silence threshold: 1.5s of quiet = transcriber.py's speaker-change gap.
SILENCE_MS = 1500

_RECORDER_JS = """
(function() {
  const root = document.getElementById("__ROOT_ID__");
  const recordBtn = root.querySelector(".wsx-record-btn");
  const stopBtn = root.querySelector(".wsx-stop-btn");
  const timerEl = root.querySelector(".wsx-timer");
  const statusEl = root.querySelector(".wsx-status");
  const silenceFill = root.querySelector(".wsx-silence-fill");
  const silenceLabel = root.querySelector(".wsx-silence-label");
  const canvas = root.querySelector(".wsx-canvas");
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;

  let stream, recorder, chunks = [], audioCtx, analyser, rafId, startTime, timerId;
  let lastLoudTime = 0;

  function fmtTime(ms) {
    const s = Math.floor(ms / 1000);
    return String(Math.floor(s / 60)).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
  }

  function draw() {
    const timeData = new Uint8Array(analyser.fftSize);
    const freqData = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteTimeDomainData(timeData);
    analyser.getByteFrequencyData(freqData);

    ctx.fillStyle = "__BG0__";
    ctx.fillRect(0, 0, W, H);

    // frequency bars (back layer)
    const barCount = 48;
    const step = Math.floor(freqData.length / barCount);
    const barW = W / barCount;
    for (let i = 0; i < barCount; i++) {
      const v = freqData[i * step] / 255;
      const barH = v * H * 0.85;
      const grad = ctx.createLinearGradient(0, H, 0, H - barH);
      grad.addColorStop(0, "__PURPLE__" + "44");
      grad.addColorStop(1, "__PINK__" + "99");
      ctx.fillStyle = grad;
      ctx.fillRect(i * barW + 1, H - barH, barW - 2, barH);
    }

    // oscilloscope waveform (front layer)
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "__PURPLE2__";
    ctx.shadowBlur = 8;
    ctx.shadowColor = "__PURPLE__";
    ctx.beginPath();
    let maxDev = 0;
    for (let i = 0; i < timeData.length; i++) {
      const x = (i / timeData.length) * W;
      const v = timeData[i] / 128.0 - 1.0;
      maxDev = Math.max(maxDev, Math.abs(v));
      const y = H / 2 + v * H * 0.4;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    // silence meter: loud = maxDev above a small noise floor
    const now = performance.now();
    if (maxDev > 0.04) { lastLoudTime = now; }
    const quietMs = now - lastLoudTime;
    const pct = Math.min(quietMs / __SILENCE_MS__, 1) * 100;
    silenceFill.style.width = pct.toFixed(0) + "%";
    if (quietMs >= __SILENCE_MS__) {
      silenceLabel.innerHTML = '<span class="wsx-silence-flash">pause &gt; 1.5s -- next speaker!</span>';
    } else {
      silenceLabel.textContent = "pause > 1.5s = next speaker";
    }

    timerEl.textContent = fmtTime(now - startTime);
    rafId = requestAnimationFrame(draw);
  }

  function b2text(blob) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  }

  window["__RESULT_PROMISE__"] = new Promise((resolveOuter) => {
    recordBtn.onclick = async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch (e) {
        statusEl.textContent = "Mic permission denied, or no mic found.";
        resolveOuter(JSON.stringify({ ok: false, error: String(e) }));
        return;
      }
      recordBtn.disabled = true;
      stopBtn.disabled = false;
      statusEl.textContent = "Recording...";
      chunks = [];
      recorder = new MediaRecorder(stream);
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.start();

      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioCtx.createMediaStreamSource(stream);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      source.connect(analyser);

      startTime = performance.now();
      lastLoudTime = startTime;
      draw();

      stopBtn.onclick = async () => {
        stopBtn.disabled = true;
        statusEl.textContent = "Converting...";
        cancelAnimationFrame(rafId);
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());  // release the mic, stop the recording indicator
          try { await audioCtx.close(); } catch (e) {}
          const blob = new Blob(chunks);
          const dataUrl = await b2text(blob);
          resolveOuter(JSON.stringify({ ok: true, data: dataUrl }));
        };
        recorder.stop();
      };
    };
  });
})();
"""

_RECORDER_HTML = """
<div id="__ROOT_ID__" class="wsx wsx-card">
  <h3>__TITLE__</h3>
  <button class="wsx-record-btn">&#9679; Record</button>
  <button class="wsx-stop-btn" disabled>&#9632; Stop</button>
  <span class="wsx-timer">00:00</span>
  <div class="wsx-status"></div>
  <div class="wsx-canvas-wrap"><canvas class="wsx-canvas" width="640" height="150"></canvas></div>
  <div class="wsx-silence-row">
    <div class="wsx-silence-label">pause > 1.5s = next speaker</div>
    <div class="wsx-silence-track"><div class="wsx-silence-fill"></div></div>
  </div>
</div>
"""


def _render_recorder(root_id: str, title: str) -> None:
    html = (_RECORDER_HTML.replace("__ROOT_ID__", root_id).replace("__TITLE__", title))
    js = (_RECORDER_JS
          .replace("__ROOT_ID__", root_id)
          .replace("__RESULT_PROMISE__", root_id + "_result")
          .replace("__SILENCE_MS__", str(SILENCE_MS))
          .replace("__BG0__", BG0).replace("__PURPLE2__", PURPLE2)
          .replace("__PURPLE__", PURPLE).replace("__PINK__", PINK))
    display(HTML(html))
    display(Javascript(js))


def record_with_ui(out_path: str = "skit.wav", title: str = "Record the skit") -> str | None:
    """Render the Record/Stop UI with a live waveform, frequency bars, and a
    silence meter, then block (via `eval_js`) until Stop is clicked.

    Returns the saved WAV path, or `None` if the mic was denied/unavailable
    (prints a plain message pointing at the backup WAV -- cells 8, 10 --
    same fallback behaviour as before, just no pre-recorded clip to swap
    in here since this is the facilitator's own live skit, not a per-prompt
    participant exercise).

    The ffmpeg webm -> wav conversion and the mic-release step are unchanged
    from the original `record_skit()`.
    """
    from google.colab.output import eval_js

    root_id = "wsxrec" + str(abs(hash(out_path)) % 100000)
    _render_recorder(root_id, title)

    import json
    raw = eval_js(f"{root_id}_result")
    result = json.loads(raw)
    if not result.get("ok"):
        print(f"No mic found, or permission denied. Use the backup WAV instead (cells 8, 10). ({result.get('error', '')})")
        return None

    data_url = result["data"]
    _, encoded = data_url.split(",", 1)
    webm_path = out_path.replace(".wav", ".webm")
    with open(webm_path, "wb") as f:
        f.write(b64decode(encoded))
    proc = subprocess.run(["ffmpeg", "-y", "-i", webm_path, out_path], capture_output=True, text=True)
    if proc.returncode != 0:
        print(proc.stderr)
        raise RuntimeError(f"ffmpeg failed converting {webm_path} -> {out_path} (see stderr above)")
    print(f"Saved {out_path}")
    return out_path


# ---------------------------------------------------------------------------
# Dark waveform + spectrogram playback panel
# ---------------------------------------------------------------------------

def dark_recording_panel(wav_path: str, title: str = "Recording") -> None:
    """A dark-themed waveform + spectrogram image, plus the audio player,
    in a themed card -- used after recording the live skit, and for the
    backup WAV playback. Reading the audio does not touch any labelling
    code; it's whisper.load_audio, the same as the participant notebook."""
    import matplotlib.pyplot as plt
    import numpy as np
    import whisper
    from IPython.display import Audio

    samples = whisper.load_audio(wav_path)
    t = np.arange(len(samples)) / 16000

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 3.6), sharex=True,
                                    facecolor=BG0)
    for ax in (ax1, ax2):
        ax.set_facecolor(BG0)
        ax.tick_params(colors=MUTED, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color("#ffffff22")
    ax1.plot(t, samples, linewidth=0.6, color=PURPLE2)
    ax1.set_ylabel("amplitude", color=MUTED, fontsize=9)
    ax1.set_title(title, color=TEXT, fontsize=12, fontweight="bold")
    with np.errstate(divide="ignore"):
        ax2.specgram(samples, Fs=16000, cmap="magma")
    ax2.set_ylabel("pitch (Hz)", color=MUTED, fontsize=9)
    ax2.set_xlabel("time (s)", color=MUTED, fontsize=9)
    plt.tight_layout()
    plt.show()
    display(Audio(wav_path))


# ---------------------------------------------------------------------------
# Progress strip (real stage boundaries, not a faked timer)
# ---------------------------------------------------------------------------

_STAGES = ["Listening...", "Transcribing...", "Labelling...", "Writing minutes..."]


def _strip_html(active: str | None, done: bool) -> str:
    spans = []
    for stage in _STAGES:
        cls = "wsx-stage"
        if done:
            cls += " done"
        elif active and stage == active:
            cls += " active"
        elif active and _STAGES.index(stage) < _STAGES.index(active):
            cls += " done"
        spans.append(f'<span class="{cls}">{stage}</span>')
    return f'<div class="wsx wsx-progress-strip">{"".join(spans)}</div>'


def start_progress_strip():
    """Displays the 4-stage strip and returns `(update, finish)`:
    - `update(stage_name)` -- call with each real stage name as
      `run_demo_staged()` reaches it, via `on_stage=update`.
    - `finish()` -- call once `run_demo_staged()` returns, to mark every
      stage done.
    Both update the SAME output in place (IPython's `display_id`), instead
    of stacking a new strip per stage."""
    handle = display(HTML(_strip_html(None, False)), display_id=True)

    def update(stage_name: str) -> None:
        handle.update(HTML(_strip_html(stage_name, False)))

    def finish() -> None:
        handle.update(HTML(_strip_html(None, True)))

    return update, finish


# ---------------------------------------------------------------------------
# Minutes cards (parses the Markdown `run_demo()`/`run_demo_staged()`
# returns -- presentation only, the text itself is untouched)
# ---------------------------------------------------------------------------

def minutes_cards_html(minutes_markdown: str) -> str | None:
    """Builds the styled-cards HTML for the exact Markdown `run_demo()`
    returned. Parses the fixed structure `generate_minutes()` always
    produces (# Meeting Minutes / **Attendees:** .../ ## Decisions /
    ## Action Items). Returns `None` if that structure doesn't match --
    callers should fall back to showing `minutes_markdown` as plain text
    instead of guessing."""
    attendees_m = re.search(r"\*\*Attendees:\*\*\s*(.+)", minutes_markdown)
    decisions_m = re.search(r"## Decisions\n(.*?)\n##", minutes_markdown, re.S)
    actions_m = re.search(r"## Action Items\n(.*)", minutes_markdown, re.S)

    if not (attendees_m and decisions_m and actions_m):
        return None

    attendees = attendees_m.group(1).strip()
    decision_lines = [l.strip()[2:] for l in decisions_m.group(1).splitlines() if l.strip().startswith("- ")]
    action_lines = [l.strip() for l in actions_m.group(1).splitlines() if l.strip().startswith("- [ ]")]

    def decision_card(text):
        return f'<div class="wsx-item"><span class="wsx-item-text">{text}</span></div>'

    def action_card(line):
        body = line[len("- [ ] "):]
        m = re.match(r"(.*?)\s--\s([^(]+?)(?:\s\(due (.+)\))?$", body)
        if not m:
            return f'<div class="wsx-item action"><span class="wsx-item-text">{body}</span></div>'
        text, owner, due = m.group(1), m.group(2).strip(), m.group(3)
        due_pill = f'<span class="wsx-pill due">due {due}</span>' if due else ""
        return (f'<div class="wsx-item action"><span class="wsx-item-text">{text}</span><br>'
                f'<span class="wsx-pill owner">{owner}</span>{due_pill}</div>')

    decisions_html = "".join(decision_card(d) for d in decision_lines) or '<div class="wsx-empty">(none)</div>'
    actions_html = "".join(action_card(a) for a in action_lines) or '<div class="wsx-empty">(none)</div>'

    return f"""
    <div class="wsx wsx-card">
      <h3>Meeting Minutes</h3>
      <div class="wsx-attendees">Attendees: {attendees}</div>
      <div class="wsx-minutes-grid">
        <div class="wsx-minutes-col"><h4>Decisions</h4>{decisions_html}</div>
        <div class="wsx-minutes-col"><h4>Action items</h4>{actions_html}</div>
      </div>
    </div>
    """


def render_minutes_cards(minutes_markdown: str) -> None:
    """Displays `minutes_cards_html()`'s result, or the plain Markdown if
    the expected structure wasn't found (unexpected shape -- show the raw
    text, don't guess)."""
    from IPython.display import Markdown

    html = minutes_cards_html(minutes_markdown)
    display(HTML(html) if html is not None else Markdown(minutes_markdown))
